import { Link } from "react-router-dom"

function ProductsMiniManu() {
  return (
    <section>
      <Link to={`/detail/${'xx99-mark-one-headphones'}`} ></Link>
    </section>
  )
}

export default ProductsMiniManu