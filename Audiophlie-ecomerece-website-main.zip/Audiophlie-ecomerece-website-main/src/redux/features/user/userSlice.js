const initialState = {
    user: null,
    isAuthChange: false,
};

// action
login: (state, {payload}) => {},
logout: (state) => {},
isAuthChange: (state, {payload}) => {}
